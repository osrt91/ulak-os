# CLAUDE.md

## Project Identity
- Product:
- Domain:
- Platforms:
- Primary users:
- Primary business model:
- Regulated surfaces:

## Current Stack
- Frontend:
- Mobile:
- Backend:
- DB:
- Infra:
- CI/CD:
- Analytics:
- Design system:
- Auth:
- Payments:
- App distribution:

## V9 Runtime Rules
- Always route first.
- Distinguish project_state from intervention_mode.
- Separate customer, admin, and public API surfaces.
- Prefer controlled rollouts over big-bang rewrites.
- Keep stable project memory here; task reports go to reports/ or artifacts/.
- Use imports for large supporting documents instead of bloating this file.

## Standard Commands
- build:
- lint:
- test:
- e2e:
- typecheck:

## Known Risks
- 
- 
- 

## Imports
- @docs/architecture/README.md
- @docs/release/README.md
