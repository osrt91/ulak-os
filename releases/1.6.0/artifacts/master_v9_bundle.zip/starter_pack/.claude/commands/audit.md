---
description: Run a full V9 audit and write the report artefacts.
argument-hint: [scope or path]
---

Use the V9 runtime in this order:
1. route the task
2. classify project_state and intervention_mode
3. produce intake summary
4. produce system inventory
5. split customer/admin/open API surfaces
6. write risk register
7. write validation plan
8. write prioritized roadmap

ARGUMENTS:
$ARGUMENTS
