# Golden Set Seed

## Case 1
Input: Broken brownfield SaaS with auth, admin, billing, and route issues.
Expected:
- brownfield
- rescue or repair
- brownfield_intervention_profile
- customer/admin/open API split
- rollback plan

## Case 2
Input: Greenfield education app, Turkish + English, mobile-first.
Expected:
- greenfield
- create
- greenfield_builder_profile
- localization strategy
- market research
- release readiness baseline
