# CLAUDE.md

@master_v10_3_autonomous_program_director_tr.md
@docs/runtime/router.md
@docs/runtime/program-phases.md
@docs/runtime/artefact-contract.md
@docs/governance/autonomy-pressure-layer.md
@docs/governance/rule-collision-matrix.md
@docs/governance/plugin-skill-decision.md

## Project Identity
- Product: TrendOfTrend
- Domain: e-commerce
- Platforms: web | mobile | admin | api
- Primary business model: marketplace + subscription
- Current state: greenfield | brownfield | hybrid

## Runtime defaults
- Prefer forward-only execution.
- If the user intent is clearly full or complete, auto-start the first artefacts.
- Keep customer, admin, and public API surfaces separate.
- Use the smallest reusable unit that solves repetition.

## Non-negotiables
- No destructive production mutation without explicit approval.
- No repeated A/B/C/D menus after a full-intent request.
- No done-claim without validation and residual risks.
