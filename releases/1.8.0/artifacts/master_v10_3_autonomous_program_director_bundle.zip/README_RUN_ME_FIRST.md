# RUN ME FIRST

## What you have
- `master_v10_3_autonomous_program_director_tr.md`
- `CLAUDE.md`
- `.claude/commands/`
- `.claude/agents/`
- `.claude/skills/`
- `.claude/settings.json`
- `.mcp.json`
- `docs/`
- `evals/`
- `reports/current/`

## Suggested first use in Claude Code
1. Open this folder as your project root.
2. Review `CLAUDE.md`.
3. Run `/director komple` or describe your task normally.
4. Let the Autonomous Program Director create and maintain the report artefacts.

## Safe default
This pack is analysis-first. It should not mutate production without explicit approval.
