# Versioning

Public releases should move in small external versions:
- 0.1.0
- 0.2.0
- 0.3.0
- ...
- 0.9.0
- 1.0.0

Keep the large internal codename separately:
- V8
- V9
- V10.2
- V10.3

Example:
Public: `0.6.0`
Codename: `V10.3 Autonomous Program Director`
