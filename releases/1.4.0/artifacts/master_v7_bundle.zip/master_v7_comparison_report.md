# MASTER V7 COMPARISON REPORT

## 0. Purpose

This report compares the current prompt family and explains why **Master V7** is the recommended final operating model for Claude-first execution.

Compared inputs:
- `master.md`
- `master_v6.md`
- `master_v6_claude_code_execution_pack.md`
- the Turkish Flutter/iOS redesign brief
- the English Flutter/iOS redesign blueprint prompt

This report answers:
1. Which prompt is best for which job?
2. What are the strengths and weaknesses of each?
3. What was still missing in V6?
4. What does V7 add?
5. Should this be called one-shot, few-shot, or something else?

---

## 1. Executive verdict

### Short answer

- **`master.md`** is still the strongest **raw technical audit and modernization skeleton**.
- **`master_v6.md`** is the strongest **model-agnostic Prompt Operating System (POS)**.
- **`master_v6_claude_code_execution_pack.md`** is the strongest **Claude Code execution harness**.
- The **Turkish redesign brief** is the strongest **visual ambition + premium direction + “kill the AI-slop” brief**.
- The **English redesign blueprint** is the strongest **screen-by-screen Flutter/iOS redesign system with implementation structure**.

### Why V7 exists

No single existing file does all of these equally well at once:

- enterprise-grade technical audit
- customer/admin/open API split security review
- Claude Code-native skills / agents / hooks / MCP / commands
- premium Flutter iOS education-app redesign
- brownfield **and** greenfield execution
- environment bootstrap and install matrix
- 2026 app distribution / privacy / adaptive quality requirements
- market-gap scanning against major Claude ecosystems

**V7 combines all of these into one unified operating model.**

---

## 2. File-by-file comparison

## 2.1 `master.md`

### Best use case
Use this when you want:
- a brutal full-project audit
- architecture modernization
- deep technical debt cleanup
- 30+ to 50+ step transformation plans
- artifact-heavy reporting
- serious multi-agent refactor planning

### Biggest strengths
- Extremely strong discovery → audit → roadmap flow
- Excellent report artifact discipline
- Strong decomposition across product, UX, FE, BE, DB, infra, security, testing, observability, SEO
- Forces severity, effort, dependency and output structure
- Excellent for brownfield systems and refactor-heavy work

### Weaknesses
- Not Claude Code-native
- No explicit skill/plugin/hook/MCP operating model
- No current prompt caching / template / variable discipline
- No CLAUDE.md hierarchy or managed settings model
- Weaker on modern mobile distribution / store compliance / adaptive layout requirements
- Not opinionated enough on modern premium frontend distinctiveness
- No bootstrap/install phase for runtimes/toolchains

### Verdict
**Keep as the technical spine.**
Do not use it alone as the final 2026 Claude operating pack.

---

## 2.2 `master_v6.md`

### Best use case
Use this when you want:
- a model-agnostic operating system prompt
- architecture + UX + security + release + governance in one place
- a broad modernization prompt not tied to one repo structure

### Biggest strengths
- Strong cross-surface thinking
- Adds prompt system ideas missing from `master.md`
- Covers feature flags, rollout, release, ASO/SEO, compliance, observability, distribution, supply chain
- Better than `master.md` for cross-platform / product-ops reality

### Weaknesses
- Still more conceptual than execution-native
- Stronger as a “system design prompt” than as a “Claude Code daily operator”
- Does not go far enough into `.claude/`, skills, commands, subagents, hook governance
- Mobile redesign is present, but not as sharp as the dedicated Flutter/iOS briefs
- Install/bootstrap behavior is still under-specified

### Verdict
**Keep as the universal POS layer.**
It remains the best model-agnostic ancestor of V7.

---

## 2.3 `master_v6_claude_code_execution_pack.md`

### Best use case
Use this when you want:
- Claude Code-first repo execution
- project-local `.claude/` topology
- skills / agents / commands / settings / MCP / hooks
- governed third-party ecosystem adoption
- execution safety and delivery gates

### Biggest strengths
- The most operational Claude Code prompt in the family
- Strongest third-party ecosystem governance
- Strong repo topology recommendations
- Strong skill authoring, subagent, hook, and MCP rules
- Clear execution gates and reusable templates

### Weaknesses
- Heavier on Claude mechanics than on design ambition
- Frontend redesign depth is good, but still not as maximal as the dedicated redesign prompts
- Lacks a fully explicit greenfield-vs-brownfield split
- Lacks a first-class bootstrap/install matrix
- Still can be improved on app-store timelines, current Apple/Android hard gates, and environment-preflight automation

### Verdict
**Keep as the Claude core.**
This is the main technical ancestor of `master_v7_claude_optimized.md`.

---

## 2.4 Turkish Flutter/iOS redesign brief

### Best use case
Use this when you want:
- maximum visual reset
- premium iOS learning-product redesign
- aggressive rejection of cheap AI-looking UI
- a calmer, whiter, blue-first, trustworthy education aesthetic
- strong visual clean-up pressure

### Biggest strengths
- Strong taste and direction
- Very clear anti-pattern detection
- Strong premium/calm/iOS-native visual intent
- Strong specific redesign pressure on cards, filters, leaderboard, navigation, sheets, menus and study flow
- Great for killing “random UI kit” damage

### Weaknesses
- Less structured as a code-execution artifact
- Less explicit about Flutter architecture migration details than the English prompt
- Less explicit about output schemas and per-screen implementation structure
- Not strong enough alone for infra/security/backend/governance

### Verdict
**Keep as the design-direction amplifier.**
This is where V7 gets its premium visual ruthlessness.

---

## 2.5 English Flutter/iOS redesign blueprint

### Best use case
Use this when you want:
- a world-class design director style audit
- a systemized screen-by-screen redesign
- strong component inventory rules
- strong Flutter implementation guidance
- explicit output sections and strict design governance

### Biggest strengths
- Best structured UI/UX redesign prompt in the family
- Excellent phase model
- Excellent component/system/token structure
- Excellent screen-by-screen checklist
- Excellent Flutter implementation translation
- Very strong for Claude Code execution because outputs are implementation-oriented

### Weaknesses
- Not enough technical/security/release depth alone
- Not enough backend/admin/open API audit depth
- Not enough toolchain/bootstrap/install behavior
- Needs to be embedded into a bigger operating system

### Verdict
**Keep as the UI system engine.**
This is where V7 gets its redesign scaffolding.

---

## 3. Side-by-side practical recommendation

| File | Best for | Main advantage | Main weakness | Keep in V7? |
|---|---|---|---|---|
| `master.md` | Deep technical audit | Hardcore modernization discipline | Not Claude-native | Yes |
| `master_v6.md` | Universal prompt OS | Broad systems thinking | Less execution-native | Yes |
| `master_v6_claude_code_execution_pack.md` | Claude Code operations | Skills/agents/hooks/MCP governance | Not design-maximal enough | Yes |
| Turkish redesign brief | Premium design direction | Taste, ambition, anti-slop pressure | Less implementation structure | Yes |
| English redesign blueprint | Flutter/iOS redesign execution | Screen-by-screen clarity | Less infra/security depth | Yes |

---

## 4. What V6 still missed

Even after V6 and the execution pack, the following gaps remained:

### 4.1 Brownfield vs greenfield split
V6 is very good for existing systems, but not explicit enough about:
- new project bootstrap
- package selection logic
- initial repo scaffolding
- runtime installation guidance
- command-line environment preparation

### 4.2 Toolchain and install intelligence
The existing family did not fully force Claude to:
- detect languages and frameworks
- list required runtimes
- list required package managers
- list native platform tooling
- list CI/CD and release tooling
- output actual install/preflight commands

### 4.3 2026 mobile distribution hard gates
The previous files did not hardwire enough of the latest realities:
- current App Store SDK requirements
- privacy manifest hygiene
- App Privacy answers discipline
- Android adaptive / large-screen quality standards
- deep-link / multi-window / foldable continuity checks

### 4.4 CLAUDE.md memory and imports strategy
The execution pack used `CLAUDE.md`, but V6 did not fully exploit:
- CLAUDE memory hierarchy
- project/user/enterprise memory split
- `@imports`
- project-local versus user-local behavior

### 4.5 Official slash-command and GitHub Actions operating model
The execution pack included commands, but V6 did not fully fold in:
- `/init`
- `/memory`
- `/agents`
- `/mcp`
- GitHub Actions use as part of the standard rollout model

### 4.6 Design references and visual synthesis
The prior pack referenced premium redesign direction, but V6 did not explicitly convert:
- the onboarding/auth softness from the inspiration shots
- the leaderboard ceremony
- the modular learning-card language
- the anti-clutter learning-dashboard rule
into a repeatable “reference synthesis” instruction block.

### 4.7 Market-comparison discipline
V6 referenced major ecosystems, but V7 needed a sharper rule:
- compare against market leaders
- borrow patterns
- reject blind adoption
- surface missing gaps explicitly

---

## 5. What official 2026 research changes the design of V7

### Claude / Anthropic side
V7 is shaped by these official realities:
- Claude Code requires Node.js 18+ and is installed via `npm install -g @anthropic-ai/claude-code`, with native install options also documented.  
- Claude memory now has clear project, user, and enterprise layers, and `CLAUDE.md` can import other files using `@path`.  
- Claude Code settings are hierarchical and support project/user/local/enterprise precedence.  
- Hooks are deterministic lifecycle controls, not mere prompt suggestions.  
- Subagents run in separate context windows and can be project- or user-scoped.  
- MCP has local, project, and user scopes, and project-scoped servers live in `.mcp.json`.  
- Prompt caching rewards a static-prefix-first layout, with `tools`, then `system`, then `messages` in cache order.

### Flutter / mobile side
V7 is also shaped by these current platform facts:
- Flutter docs currently reflect the 3.41.x line and emphasize adaptive/responsive design across phones, foldables, tablets and larger screens.
- Flutter’s Cupertino library remains the official path for high-fidelity Apple-aligned widgets.
- Android’s adaptive app quality guidelines were refreshed in early 2026 and now explicitly require better treatment of large screens, contextual menus, secondary elements and adaptive navigation.
- Apple’s HIG continues to distinguish tab bars for navigation and toolbars for commands/search/actions, and recommends large titles plus careful toolbar crowding control.
- Apple now requires newer SDK baselines for App Store submissions in 2026, and privacy disclosures remain a hard gate.

---

## 6. What V7 adds on top

V7 adds all missing layers at once:

1. **Standard prompt file**
   - model-agnostic
   - good for Claude, OpenAI, Gemini, internal agents
   - works for greenfield and brownfield

2. **Claude-optimized execution pack**
   - XML-tag structured
   - CLAUDE.md-ready
   - subagent/skills/hooks/MCP aware
   - command-pack aware
   - prompt-caching aware

3. **Bootstrap/install phase**
   - detect stack
   - list runtime/tooling requirements
   - recommend install commands
   - separate must-have vs optional toolchains

4. **New/brownfield selector**
   - `PROJECT_STATE: greenfield | brownfield | hybrid`
   - different mandatory outputs depending on state

5. **UI reference synthesis**
   - attached inspiration images are converted into reusable design guidance
   - no direct copying allowed
   - premium but restrained system is enforced

6. **Current platform gates**
   - App Store readiness
   - privacy manifest / privacy response readiness
   - Android adaptive readiness
   - deep-link / broken-link / broken-endpoint parity
   - store listing / legal URL integrity

7. **Market gap scan**
   - compare against official Anthropic ecosystem
   - compare against AITMPL patterns
   - compare against Everything Claude Code / SuperClaude / large skill bundles
   - identify what is worth adopting, rewriting, or ignoring

---

## 7. Is this one-shot, three-shot, or four-shot?

### Best answer
**Neither pure one-shot nor bulky four-shot.**

The best classification for V7 is:

> **A zero-shot core operating system with optional lightweight few-shot exemplars.**

### Why
- The main prompt is already highly structured.
- Claude performs better when the system is clean, modular, and explicit.
- Huge four-shot blocks inside the core prompt increase cost and context bloat.
- For this reason, V7 uses:
  - a strong system contract
  - strong variable/input contracts
  - optional example blocks only when needed

### Recommendation
Default workflow:
- **Zero-shot core** for daily usage
- **1–2 short examples** only for:
  - output JSON structure
  - screen-by-screen checklist formatting
  - Jira bundle formatting

So the practical label is:

> **“Claude-first execution pack, few-shot-ready but zero-shot by default.”**

---

## 8. What is better than our current stack in the market?

### Short answer
Pieces of the market are better in specific areas, but not as a whole system.

### Where external ecosystems are stronger
- Some official Anthropic capabilities are stronger in **tight platform-native behavior**
- AITMPL is stronger in **distribution and discoverability**
- Everything Claude Code is stronger in **breadth and ecosystem momentum**
- SuperClaude is stronger in **persona/command theater and packaged lifecycle ergonomics**
- Large public skill collections are stronger in **catalog size**

### Where they are weaker than V7
Most market packs are weaker in at least one of these:
- enterprise governance
- customer/admin/open API split auditing
- premium Flutter iOS redesign depth
- secure third-party adoption discipline
- technical + design + release + store + compliance unification
- explicit bootstrap and install intelligence
- brownfield + greenfield in one contract

### Practical conclusion
V7 should not try to “out-catalog” the market.
It should win by:
- stricter governance
- higher evidence quality
- deeper technical + design integration
- better controlled execution
- better Flutter/iOS learning-product specialization

---

## 9. Final recommendation

### Use these files together
- `master_v7_standard.md` → universal system prompt / planning prompt / model-agnostic file
- `master_v7_claude_optimized.md` → Claude Code primary operating pack
- This comparison report → governance and usage guidance

### Default usage rule
- If working **inside Claude Code on the real repo** → use `master_v7_claude_optimized.md`
- If working **outside Claude Code or in mixed tooling** → use `master_v7_standard.md`

### Final strategic verdict
V7 is the first version that:
- keeps the brutal technical discipline of the original master
- keeps the cross-surface scope of V6
- keeps the execution reality of the Claude execution pack
- keeps the premium redesign pressure of the UI prompts
- adds missing 2026 toolchain, store, adaptive, memory, and bootstrap intelligence

That is why V7 is the correct release candidate.
