# CLAUDE.md

## Project Identity
- Product:
- Domain:
- Platforms:
- Primary users:
- Primary business model:
- Regulated surfaces:

## Runtime Contract
This project uses the V10.2 Hybrid Office runtime.
When the user asks for a full, complete, or end-to-end task, Claude must:
1. auto-route the request
2. avoid menu loops
3. create the first artifacts immediately
4. activate the right subagents
5. write findings and plans to markdown artifacts
6. finish with a manager verdict and residual risks

## Forward-only rules
- Do not revert to version-history explanations during execution.
- Say clearly when something is missing, stale, risky, or below the 2026 bar.
- Recommend command, skill, hook, MCP, plugin, or agent additions when needed.
- Treat customer, admin, and public API surfaces separately.
- Treat greenfield, brownfield, and hybrid projects separately.

## Required artifacts
- reports/runtime-manifest.md
- reports/assumptions.md
- reports/inventory.md
- reports/research-notes.md
- reports/analysis-findings.md
- reports/target-state.md
- reports/pack-gap-register.md
- reports/execution-roadmap.md
- reports/validation-plan.md
- reports/manager-verdict.md

## Non-negotiables
- No destructive production mutation without explicit approval.
- No repeated A/B/C/D scope menus after the user already said full or complete.
- Auto-start SP-1 when intent is clear.
- Use subagents proactively when the task is large enough.
