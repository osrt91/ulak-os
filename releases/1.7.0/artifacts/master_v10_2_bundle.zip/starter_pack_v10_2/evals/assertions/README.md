Assertions should verify: no menu loop after clear full intent, artifact creation starts automatically, manager verdict exists, missing add-ons are escalated, and validation gates are explicit.
