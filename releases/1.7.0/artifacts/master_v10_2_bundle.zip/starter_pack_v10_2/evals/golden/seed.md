# Golden scenarios

1. Full greenfield build request
2. Brownfield rescue from mid-project state
3. Existing project final-phase hardening and release readiness
4. Localization repair with Turkish characters and locale edge cases
5. Frontend redesign with education app constraints
6. Customer/admin/public API split audit
