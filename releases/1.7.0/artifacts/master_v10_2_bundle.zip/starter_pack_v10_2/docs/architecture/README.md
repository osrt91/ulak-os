Store target architecture and migration decisions here.
