The V10.2 runtime is a hybrid office model with one executive orchestrator and up to 20 specialist subagents.
