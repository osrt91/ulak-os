Record architecture decisions here.
