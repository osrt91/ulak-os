This folder stores runtime-manifest, assumptions, inventory, research notes, findings, roadmap, validation, and manager verdict artifacts.
