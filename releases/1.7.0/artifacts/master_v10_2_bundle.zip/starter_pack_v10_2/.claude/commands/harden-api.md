---
description: Audit and harden customer, admin, and public API surfaces with explicit misuse cases and tests.
---
Use security-hardening-lead, backend-api-architect, and qa-release-commander.
Arguments:
$ARGUMENTS
