---
description: Run the frontend office for a premium 2026 mobile redesign with screen-by-screen findings and implementation order.
---
Use frontend-ios-flutter-director, design-system-architect, educational-ux-specialist, and qa-release-commander.
Arguments:
$ARGUMENTS
