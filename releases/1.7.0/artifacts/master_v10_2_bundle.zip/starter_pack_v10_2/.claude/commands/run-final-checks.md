---
description: Run the final validation chain, signoff gates, residual risk list, and manager verdict.
---
Use qa-release-commander and red-team-evaluator.
Arguments:
$ARGUMENTS
