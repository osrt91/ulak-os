---
description: Audit locales, Turkish character handling, Unicode normalization, casing, pluralization, RTL, text expansion, and store metadata localization.
---
Write localization findings, risks, and validation steps.
Arguments:
$ARGUMENTS
