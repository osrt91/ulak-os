---
description: Detect missing pack components and either create them or backlog them explicitly with owner, risk, and validation.
---
Produce pack-gap-register.md.
Escalate missing command, skill, hook, MCP, plugin, eval, and docs items.
Arguments:
$ARGUMENTS
