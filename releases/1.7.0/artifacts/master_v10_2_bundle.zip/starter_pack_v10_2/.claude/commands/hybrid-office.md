---
description: Activate the executive orchestrator and the specialist office model for large multi-surface work.
---
Load the hybrid office roster.
Select the minimum sufficient agent set.
Open a red-team pass before final signoff.
Arguments:
$ARGUMENTS
