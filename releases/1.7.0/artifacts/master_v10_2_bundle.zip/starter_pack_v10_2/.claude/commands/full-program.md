---
description: Auto-route a complete end-to-end program without returning to scope menus. Create artifacts, activate subagents, and finish with a manager verdict.
---
Run the V10.2 hybrid office runtime.
Do not ask repetitive scope menus.
Create the first artifacts immediately.
Use the right subagents proactively.
Arguments:
$ARGUMENTS
