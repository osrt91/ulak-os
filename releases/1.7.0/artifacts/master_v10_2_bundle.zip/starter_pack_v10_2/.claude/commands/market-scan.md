---
description: Run market, competitor, positioning, pricing, language, and category-gap research for the current product.
---
Produce research-notes.md and upgrade recommendation cards.
Arguments:
$ARGUMENTS
