---
name: security-hardening
description: Audit and harden authentication, authorization, customer/admin/public API boundaries, abuse prevention, secrets, dependency risk, and release-blocking security issues. Use when working on auth, admin panels, billing, data access, or public endpoints.
---

# Security Hardening

Always return severity, exploit path, recommended remediation, and verification steps.
