---
name: project-audit
description: Deeply audit a software project across product, architecture, frontend, backend, security, testing, release, localization, customer/admin surfaces, and public APIs. Use when the user asks for a full project read, modernization plan, brownfield rescue, or production hardening review.
---

# Project Audit

1. Map the project surfaces and evidence.
2. Split customer, admin, and public API surfaces.
3. Identify critical and missing components.
4. Create findings, target state, roadmap, and validation outputs.
