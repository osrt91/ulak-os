---
name: frontend-redesign
description: Redesign outdated or generic interfaces into a coherent premium system with reusable components, modern hierarchy, and implementation-ready guidance. Use for Flutter, iOS, Android, dashboard, education, and redesign-heavy work.
---

# Frontend Redesign

1. Audit first.
2. Rebuild design rules.
3. Produce screen-by-screen redesign notes.
4. Define implementation order and states.
