---
name: final-validation
description: Run final validation, residual risk review, red-team challenge, and manager verdict generation. Use when the project has moved from discovery into signoff or release-readiness review.
---

# Final Validation

Confirm the artifact chain, unresolved gaps, validation status, and manager verdict.
