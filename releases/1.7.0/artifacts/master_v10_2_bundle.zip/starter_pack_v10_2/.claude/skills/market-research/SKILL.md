---
name: market-research
description: Analyze competitors, positioning, pricing, messaging, category gaps, language opportunities, and 2026 market expectations. Use when product direction, market fit, naming, localization, or competitive strategy must be grounded in evidence.
---

# Market Research

Produce research-notes.md with evidence, gap analysis, strategic implications, and recommendation cards.
