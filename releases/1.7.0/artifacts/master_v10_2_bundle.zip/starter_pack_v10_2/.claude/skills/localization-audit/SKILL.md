---
name: localization-audit
description: Audit language coverage, Turkish character correctness, Unicode normalization, locale-aware casing, pluralization, RTL, text expansion, and store metadata localization. Use when the product must support multilingual users or text quality defects are visible.
---

# Localization Audit

Check:
- locale inventory
- Turkish text correctness
- search vs display normalization
- formatting by locale
- translation and rollout risks
