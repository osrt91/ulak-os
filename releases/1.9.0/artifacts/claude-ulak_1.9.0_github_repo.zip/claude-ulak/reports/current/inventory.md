# Inventory

## files and folders
- 

## routes and screens
- 

## endpoints
- 

## dependencies
- 

## customer/admin/public split
- 
