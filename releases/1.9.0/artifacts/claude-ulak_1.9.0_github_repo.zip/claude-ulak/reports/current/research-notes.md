# Research Notes

## market signals
- 

## competitors
- 

## architecture currency
- 

## language opportunities
- 

## open questions
- 
