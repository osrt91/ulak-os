# Version package metrics

Bu metrikler eldeki zip dosyalarından türetildi.

- V7 bundle: 3 dosya
- V9 bundle: 1 command, 1 agent, starter pack
- V10.2 bundle: 8 command, 21 agent, 6 skill, docs/evals/report iskeleti
- V10.3 bundle: 5 command, 20 agent, 4 skill, runtime docs, artefakt şablonları ve bootstrap

Bu sayılar; sistemin salt metin prompttan çalışma topolojisine geçtiğini gösterir.
