# Version History and Release Strategy

## Net görüş
Eski büyük numaraları iç kullanım kod adı olarak tut.
GitHub üzerinde ise küçük ve kontrollü dış sürümler kullan.

Yani:
- içeride: `V8`, `V9`, `V10.2`, `V10.3`
- dışarıda: `0.3.0`, `0.4.0`, `0.5.0`, `0.6.0`

## Retrospektif kanonik tarihçe

### 0.1.0 — Master Core Baseline
**Kod adı:** Master + Front-End Base
- ana master prompt yaklaşımı
- frontend redesign yönü
- kapsamlı teknik ve deneyim denetimi fikri

### 0.2.0 — Operating System Expansion
**Kod adı:** V6 Prompt Operating System
- mod seçimi
- kapsam matrisi
- overlay mantığı
- security / QA / release / compliance katmanları

### 0.3.0 — Language / Market / Architecture Hardening
**Kod adı:** V8
- language coverage audit
- Turkish normalization
- market research engine
- architecture currency protocol
- localization release gates

### 0.4.0 — Adaptive Runtime Router
**Kod adı:** V9
- runtime router
- context budget manager
- intervention modes
- canonical output profiles
- hidden core / public runtime surface

### 0.5.0 — Hybrid Office Front OS
**Kod adı:** V10.2
- 1 yönetici + 20 uzman yaklaşımı
- command / skill / agent / MCP karar kuralları
- managed full-program mode
- artefakt zinciri zorunluluğu

### 0.6.0 — Autonomous Program Director
**Kod adı:** V10.3
- one-file bootstrap
- otomatik klasör üretimi
- CLAUDE.md + `.claude/` + docs + evals + reports kurulumu
- ajan, command, skill ve ayar scaffold’ı
- GitHub’a taşınabilir repo temeli

## Bundan sonrası
### 0.6.1
- küçük düzeltmeler
- README / CHANGELOG / repo polish
- one-file script hardening

### 0.7.0 — Pack Hardening
- daha iyi eval kapsamı
- assertion seti
- no-menu-loop regression testleri
- daha güçlü pack-gap heuristics

### 0.8.0 — Multi-Project Intelligence
- sektör pack’leri
- daha iyi plugin/skill generation policy
- reusable templates

### 0.9.0 — Release Candidate
- public repo cleanup
- contributor docs
- examples
- demo bundles

### 1.0.0 — Public Stable
- kararlı dış arayüz
- net versioning policy
- release disiplini oturmuş

## Kısa karar
Repo’da şu dili kullan:
**Release 0.6.0 — Internal codename: V10.3 Autonomous Program Director**
