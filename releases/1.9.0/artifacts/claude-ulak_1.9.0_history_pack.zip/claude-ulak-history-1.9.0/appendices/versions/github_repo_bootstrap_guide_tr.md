# GitHub Repo Bootstrap Guide — V10.3

## Amaç
Bu repo, tek dosya çalıştırıcıdan başlayan ama zamanla tam bir Prompt Operating System / Claude Code pack / hybrid office runtime haline gelen sistemi düzenli, yayınlanabilir ve sürdürülebilir hale getirmek için hazırlanır.

## Önerilen repo adı
- `autonomous-program-director`
- `prompt-operating-system`
- `claude-hybrid-office`
- `project-autopilot-pack`

Benim önerim: **`autonomous-program-director`**

## Repo yapısı
```text
repo-root/
├── README.md
├── LICENSE
├── CHANGELOG.md
├── ROADMAP.md
├── VERSIONING.md
├── CLAUDE.md
├── master/
├── onefile/
├── bundles/
├── .claude/
├── docs/
├── evals/
├── reports/
└── examples/
```

## Branch stratejisi
- `main` → kararlı
- `dev` → entegre geliştirme
- `feature/*` → yeni modül
- `release/*` → release hazırlığı
- `hotfix/*` → acil düzeltme

## Tag/release stratejisi
Dışa açık release tag’lerinde büyük sıçramalar yerine küçük ilerleme göster:
- `v0.1.0`
- `v0.2.0`
- `v0.3.0`
- ...
- `v0.9.0`
- `v1.0.0`

İç codenameler release notes içinde kalabilir:
- Internal codename: `V10.3 Autonomous Program Director`
- Public release tag: `v0.6.0`

## README başlıkları
1. Bu sistem ne yapar?
2. Tek dosya nasıl çalıştırılır?
3. Bundle nedir?
4. `CLAUDE.md` ve `.claude/` neden var?
5. Greenfield / brownfield / rescue desteği
6. Katkı ve release akışı

## Benden isteyebileceğin destekler
- README yazımı
- CHANGELOG düzeni
- VERSIONING.md
- release note taslağı
- ilk issue / milestone seti
- repo açıklaması ve kısa tanıtım metni
- CONTRIBUTING.md taslağı
- public/private ayrımı
- ilk Git tag planı
