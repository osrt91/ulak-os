# CHANGELOG Template

## [0.6.0] — V10.3 Autonomous Program Director

### Added
- One-file bootstrap generator
- CLAUDE.md import chain
- `.claude/commands`, `.claude/agents`, `.claude/skills` scaffold
- docs / evals / reports klasörleri

### Changed
- Runtime artık tek prompttan pack yapısına evrildi
- Full-intent isteklerde menu loop azaltıldı

### Hardened
- Artefakt zinciri
- Manager verdict
- Pack-gap register
- Validation plan

### Fixed
- Tekrar eden scope soruları
- Dağınık çıktı yerine rapor disiplinine geçiş

### Removed
- Gereksiz genel yönlendirme
- Full-intent durumda tekrar kapsam menüsü açma alışkanlığı

### Known limitations
- Repo erişimi yoksa kanıt gücü sınırlı kalır
- MCP / connector yoksa dış sistemlerle doğrudan çalışma sınırlıdır
- Her proje için ek hardening gerekebilir
