# What improved by release

## 1.5.0 / V8
- dil fırsatları ve lokalizasyon ciddi bir yüzey oldu
- Türkçe karakter / Unicode / locale-aware eşleştirme explicit hale geldi
- market research ve architecture currency zorunlu katman oldu

## 1.6.0 / V9
- router karar mantığı geldi
- context budget yönetimi geldi
- create/repair/extend/refactor/migrate/rescue/repackage ayrımı netleşti

## 1.7.0 / V10.2
- sistem "tek model cevap versin" mantığından çıkıp ofis mantığına geçti
- manager + uzmanlar modeli tanımlandı
- kullanıcı full intent verirse scope menüsü açmama kuralı sertleşti

## 1.8.0 / V10.3
- artefakt zinciri tamamlandı
- pack-gap escalation standartlaştı
- tek dosya bootstrap ile üretim kolaylaştı

## 1.9.0 / Claude Ulak
- GitHub repo formatı hazırlandı
- Claude/Codex/Gemini dağıtım yüzeyleri eklendi
- public release line birleştirildi
