# Major decisions

## 1) Sürüm çizgisi 0.x yerine 1.x oldu
Kullanıcının talebi doğrultusunda tarihsel çizgi 1.0.0’dan başlatıldı. İç sürüm isimleri arşiv amaçlı tutuldu.

## 2) Tek vendor prompt yerine çekirdek + adaptör modeli seçildi
Aynı davranışı üç ayrı prompt kopyasıyla değil; ortak çekirdek ve platform dosyalarıyla taşıma kararı alındı.

## 3) Full intent’te menü döngüsü antipattern sayıldı
"Komple" gibi niyetlerde sistemin tekrar A/B/C/D menüsü açması kırılması gereken davranış olarak tanımlandı.

## 4) Artefakt üretimi zorunlu hale geldi
Önemli kararlar sohbet içinde kaybolmasın diye reports/current zinciri standardize edildi.

## 5) Hibrit ajan ofisi kalıcı hale geldi
V10.2 ile tanımlanan çoklu ajan yaklaşımı, V10.3’te yönetici merkezli hale getirildi.

## 6) Tarihsel farklar kullanıcıdan saklanabilir, maintainers’tan saklanamaz
Public runtime ile hidden maintainer surface ayrımı bu nedenle korundu.
