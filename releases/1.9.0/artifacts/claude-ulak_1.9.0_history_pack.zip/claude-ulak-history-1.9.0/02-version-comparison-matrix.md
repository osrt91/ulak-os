# Version comparison matrix

| Public | Internal | Ana katkı | Yeni yapı taşı | Önceki sorunu nasıl çözdü |
|---|---|---|---|---|
| 1.0.0 | ancestral | Ana audit/refactor çekirdeği | teknik denetim omurgası | yüzeysel analiz yerine sistematik bakış |
| 1.1.0 | ancestral | Premium frontend brief | iOS/Flutter redesign standardı | generic ve zayıf UI eleştirisini sistemleştirdi |
| 1.2.0 | V6 | Prompt OS düşüncesi | kapsam matrisi, overlay, governance | promptu yalnız cevap değil, işletim modeli yaptı |
| 1.3.0 | V6.6 | Execution-first Claude yönelimi | skills/plugins/subagents/hooks/MCP | icra edilebilir topoloji oluşturdu |
| 1.4.0 | V7 | İlk bundle konsolidasyonu | standard + optimized + comparison | dağınık birikimi paket haline getirdi |
| 1.5.0 | V8 | Dil/market/architecture sertleştirmesi | Turkish normalization, market research, currency protocol | Türkçe, locale ve güncel mimari açıklarını kapattı |
| 1.6.0 | V9 | Adaptive runtime | router, context budget, intervention modes | dev prompt şişmesini ve yönsüzlüğü azalttı |
| 1.7.0 | V10.2 | Hibrit ajan ofisi | 20 uzman + manager benzeri yapı | "komple" istekte tekrar menü açma sorununu hedefledi |
| 1.8.0 | V10.3 | Program director | artefakt zinciri + tek dosyalı bootstrap | tam programı bir yönetici üzerinden yönetti |
| 1.9.0 | current | Dağıtım ve ürünleşme | Claude Ulak repo, Codex/Gemini adaptörleri | sistemi GitHub’a ve farklı agent ekosistemlerine taşınabilir hale getirdi |
