# Claude Ulak — Historical Dossier 1.9.0

Bu paket, yapılan tüm evrimi tek yerde toplar:
- sürüm soyağacı,
- iç/dış sürüm eşleşmesi,
- büyük değişiklikler,
- eksikler ve sonraki adaylar,
- yüklenen ham metin kaynakları,
- korunmuş iç sürüm dosyaları.

Not: Kullanıcının paylaştığı eski ChatGPT share link’i bu ortamda doğrudan çözümlenemedi. Bu nedenle tarihsel rekonstrüksiyon; mevcut sohbet, yüklenen düz metin dökümleri ve daha önce üretilmiş paket dosyaları üzerinden yapıldı.
