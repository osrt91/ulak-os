# Remaining gaps and next candidates

## Hâlâ eksik / saha doğrulaması isteyen alanlar
- gerçek repo pilotları yok veya sınırlı
- vendor adaptörlerinin saha regresyon geçmişi henüz kısa
- otomatik CI/validation akışı henüz repo standardı değil
- eval seti daha da büyümeli
- GitHub release automation katmanı henüz basit

## Güçlü V11 / 2.0 adayları
- çoklu repo pilot sonucu ekleme
- GitHub Actions ve release botları
- eval dashboard
- adapter parity testleri
- pack-gap discovery otomasyonu
