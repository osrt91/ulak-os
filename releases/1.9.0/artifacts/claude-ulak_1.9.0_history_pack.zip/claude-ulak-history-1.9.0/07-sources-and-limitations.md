# Sources and limitations

## Kullanılan kaynaklar
- mevcut sohbet akışı
- yüklenen ham metin dosyaları
- daha önce üretilmiş V7/V8/V9/V10.2/V10.3 dosyaları

## Sınırlama
Eski share link doğrudan alınamadığı için ilk dönem rekonstrüksiyon yüzde yüz birebir transcript tabanlı değildir; ama eldeki somut artefaktlar ve kullanıcı mesajları üzerinden yeterli doğrulukta yeniden kurulmuştur.
